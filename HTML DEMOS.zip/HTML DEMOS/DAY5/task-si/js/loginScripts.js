//external javascript

function verifyLogin(loginForm)
{
    if(loginForm.checkValidity()){
        var username=loginForm.txtUN.value;
        var password=loginForm.txtPwd.value;

        if(username === 'admin@gmail.com' && password === 'admin123')
        {
            alert('Login Successful');
            localStorage.setItem("username",username);
            window.open("../pages/simpleInterest.html","_blank");
        }
        else
            alert('Invalid username or password!!');
    }
}