function calculateSI(pa, roi, noy) {
    var si = parseFloat(pa.value) 
                * parseFloat(roi.value) 
                        * parseInt(noy.value) / 100; 
                        
//alert('Simple Interest is '+si);    
document.getElementById("lblResult").innerText  
            = 'Simple Interest is '+si;
         }

function clearAll()
{
    document.getElementById("lblResult").innerHTML="";

}
function verifyUser()
{
    if(localStorage.getItem("username")==null)
    {
        window.open("../index.html");
    }
}

function logOff()
{
    if(localStorage.username)
    {
        //removing individually by key name
        localStorage.removeItem("username");
        //removing all keys with clear() function
        //optional
        localStorage.clear();
        window.open("../index.html");
    }
}