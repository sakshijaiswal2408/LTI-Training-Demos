//external java script

//using ternary
function checkEvenOdd()
{
    var num= parseInt(prompt("Enter Number: ",0));

    var result=(num==0)
                    ? num+" is neither even or odd..!"
                    : (num%2==0) ? num+" is even number..!"
                    : num+ " is an odd number..!";

    document.getElementById("result").innerHTML = result;

}

//using if and else
function checkMax()
{
    var firstNumber= parseFloat(prompt("Enter First Number: ",0));
    var secondNumber= parseFloat(prompt("Enter Second Number: ",0));

    if(firstNumber==secondNumber)
    {
        var result="Both are equal";
    }
    else if(firstNumber > secondNumber )
    {
        result = firstNumber+" is greater than "+secondNumber;
    }
    else
    {
        result = firstNumber+" is smaller than "+secondNumber;
    }
    document.getElementById("result").innerHTML = result;
}

function checkVowels()
{
    var input= prompt("Enter a letter: ");
    var code=input.charCodeAt(input);

    console.log(code);
    //if(isNan(input))
    if((code>=65 && code<=90) || (code>=97 && code<=122))
    {
        var result;
        switch(input.toUpperCase())
        {       
            case 'A': 
            case 'E':
            case 'I': 
            case 'O':
            case 'U': result=input+ " is a VOWEL";
            break;
            default: result=input+ " is a CONSONANT";    
        }
    }
    else
        result="Enter letter from [A-Z] or [a-z]";
    document.getElementById("result").innerHTML = result;
}

//while loop
function printConsecutiveNumbers()
{
    var num= parseInt(prompt ("Enter number: ",0));

    var numbers;

    //Step1: Initialization
    var i=1;
    //Step2: Test Condition
    while(i<=num)
    {
        numbers=numbers +","+i;         //Step3: Body Of the Loop
        i++;                            //Step4: Increment or Decrement
    }
    document.getElementById("message").innerHTML= "NUMBERS FROM 1 to "+num+" are <br/>"+numbers;
}

//For Loop
function findFactorial()
{
    var num = parseInt(prompt("Enter Number: ",0));

    var fact=1;

    for(var i=1;i<=num;i++)
    {
        fact*=i;
    }
    document.getElementById("message").innerHTML ="Factorial of "+num+ " is " +fact;
}

function sumOfConsecutiveNumbers()
{
    var num = parseInt(prompt("Enter Number: ",0));
    var sum=0;
    var i=1;
    do
    {
        sum+=i;
        i++;

    }while (i<=num)
    document.getElementById("message").innerHTML ="Sum is "+num+ " is " +sum;
}

