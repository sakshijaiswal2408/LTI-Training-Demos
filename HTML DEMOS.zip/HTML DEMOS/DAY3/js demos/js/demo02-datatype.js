//external javascript

//variables and functions in JS must follow camelCase

var anyType;
document.write("anyType: <b> "+anyType+"</b> "+" typeOf(anyType): <b><i> "+typeof(anyType)+" </i></b> ");


anyType="Sakshi";
document.write("anyType: <b> "+anyType+"</b> "+" typeOf(anyType): <b><i> "+typeof(anyType)+"</i></b>");

anyType=1000;
document.write("anyType: <b>"+anyType+"</b> "+"typeOf(anyType): <b><i>"+typeof(anyType)+"</i></b>");

anyType=1000.052;
document.write("anyType: <b>"+anyType+"</b> "+"typeOf(anyType): <b><i>"+typeof(anyType)+"</i></b>");

anyType=1000.052;
document.write("anyType: <b>"+anyType+"</b> "+"typeOf(anyType): <b><i>"+typeof(anyType)+"</i></b>");